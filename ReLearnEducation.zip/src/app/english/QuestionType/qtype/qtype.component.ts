import { Component } from '@angular/core';

@Component({
  selector: 'app-qtype',
  templateUrl: './qtype.component.html',
  styleUrls: ['./qtype.component.scss']
})
export class QTypeComponent {

}
