import { Component } from '@angular/core';

@Component({
  selector: 'app-blend-words',
  templateUrl: './blend-words.component.html',
  styleUrls: ['./blend-words.component.scss']
})
export class BlendWordsComponent {

}
