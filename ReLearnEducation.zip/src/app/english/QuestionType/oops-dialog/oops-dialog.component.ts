import { Component } from '@angular/core';

@Component({
  selector: 'app-oops-dialog',
  templateUrl: './oops-dialog.component.html',
  styleUrls: ['./oops-dialog.component.scss']
})
export class OopsDialogComponent {

}
