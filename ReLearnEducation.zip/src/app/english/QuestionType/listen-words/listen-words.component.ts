import { Component } from '@angular/core';

@Component({
  selector: 'app-listen-words',
  templateUrl: './listen-words.component.html',
  styleUrls: ['./listen-words.component.scss']
})
export class ListenWordsComponent {

}
