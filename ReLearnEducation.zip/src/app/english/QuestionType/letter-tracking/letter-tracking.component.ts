import { Component } from '@angular/core';

@Component({
  selector: 'app-letter-tracking',
  templateUrl: './letter-tracking.component.html',
  styleUrls: ['./letter-tracking.component.scss']
})
export class LetterTrackingComponent {

}
